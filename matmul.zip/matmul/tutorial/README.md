## Beating NumPy's Matrix Multiplication in 150 Lines of C Code

[https://salykova.github.io/matmul-cpu](https://salykova.github.io/matmul-cpu)